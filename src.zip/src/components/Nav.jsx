import React from 'react'
import './Nav.css'
function Nav() {
  return (
    <div className='nav'>
      <img width={'150px'} src="https://logos-world.net/wp-content/uploads/2020/04/Netflix-Logo.png" alt="netflix logo" />
    </div>
  )
}

export default Nav
